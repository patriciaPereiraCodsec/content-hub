from __future__ import annotations

from typing import Any, Coroutine, Iterable

import asyncio
import requests

from SiemplifyAction import SiemplifyAction
from SiemplifyConnectors import SiemplifyConnectorExecution
from SiemplifyJob import SiemplifyJob
from SiemplifyLogger import SiemplifyLogger

from .interfaces.logger import Logger, ScriptLogger
from ..data_models import Container
from ..exceptions import ActionSetupError
from ..types import ChronicleSOAR, Entity, GeneralFunction


class CreateSession:
    @staticmethod
    def create_session() -> requests.Session:
        return requests.Session()


def create_soar_action() -> SiemplifyAction:
    return SiemplifyAction()


def create_soar_job() -> SiemplifyJob:
    return SiemplifyJob()


def create_soar_connector() -> SiemplifyConnectorExecution:
    return SiemplifyConnectorExecution()


def create_params_container() -> Container:
    return Container()


def create_logger(chronicle_soar: ChronicleSOAR) -> ScriptLogger:
    return NewLineLogger(chronicle_soar.LOGGER)


def nativemethod(method: GeneralFunction) -> GeneralFunction:
    """Decorator that marks a method as native.

    Args:
        method (function): The method to mark as native.

    Returns:
        function: The decorated method.
    """
    method.is_native = True
    return method


def is_native(method: GeneralFunction) -> bool:
    """Returns True if the method is marked as native, False otherwise.

    Args:
        method (function): The method to check.

    Returns:
        bool: True if the method is marked as native, False otherwise.
    """
    if hasattr(method, "is_native"):
        return method.is_native
    return False


def validate_manager(manager: Any) -> None:
    if manager is None:
        raise ActionSetupError(
            "Cannot run this action without a manager! (manager is None)\n"
        )


def validate_entity(entity: Entity) -> None:
    if entity is None:
        raise ActionSetupError(
            "Cannot run this action on null entity! (entity is None\n"
        )


class NewLineLogger(Logger):
    def __init__(self, logger: SiemplifyLogger) -> None:
        self.logger = logger

    def debug(self, msg: str, *args, **kwargs) -> None:
        self.logger.info(f"{msg}\n", *args, **kwargs)

    def info(self, msg: str, *args, **kwargs) -> None:
        self.logger.info(f"{msg}\n", *args, **kwargs)

    def warn(self, warning_msg: str, *args, **kwargs) -> None:
        self.logger.warn(f"{warning_msg}\n", *args, **kwargs)

    def error(self, error_msg: str, *args, **kwargs) -> None:
        self.logger.error(f"{error_msg}\n", *args, **kwargs)

    def exception(self, ex: Exception, *args, **kwargs) -> None:
        self.logger.exception(ex, *args, **kwargs)


def coros_with_limit(coros: Iterable[Coroutine], limit: int) -> list[Coroutine]:
    """Rate limit number of coroutines that can be executed simultaneously.

    Args:
        coros (Iterable[Coroutine]): iterable containing coroutines to be executed
        limit (int): maximum number of coroutines to be executed in parallel

    Returns:
        list[Coroutine]: list of wrapped coroutines enclosed into asyncio.Semaphore
    """
    sem = asyncio.Semaphore(limit)

    async def await_coro(coro: Coroutine):
        async with sem:
            return await coro

    return [
        await_coro(coro) for coro in coros
    ]
