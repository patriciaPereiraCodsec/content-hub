import os
import sys
import json
import TIPCommon
# Imported TIPCommon object to prevent import failing that caused due to two modules import from one another


PYTHON_2 = 2
PYTHON_3 = 3


def get_system_python_major_version():
    """
    Check if the python version of the system is 3.7 or above.
    :return: (bool) True if the current python version is at least 3.7.
    """
    return sys.version_info.major


if get_system_python_major_version() == PYTHON_3:
    from abc import ABC, abstractmethod

    ##################
    # DATA INTERFACE #
    ##################

    class AbstractDataStream(ABC):
        """
        An abstract class (supporting python 3) containing mandatory methods that all data types should implement.
        This gives the ability to control that each data type class overrides methods with the same signature.
        """

        @abstractmethod
        def validate_existence(self, default_value_to_set):
            pass

        @abstractmethod
        def read_content(self, default_value_to_return):
            pass

        @abstractmethod
        def write_content(self, content_to_write, default_value_to_set):
            pass

if get_system_python_major_version() == PYTHON_2:
    from abc import ABCMeta, abstractmethod


    class AbstractDataStream:
        """
        An abstract class (supporting python 2) containing mandatory methods that all data types should implement.
        This gives the ability to control that each data type class overrides methods with the same signature.
        """
        __metaclass__ = ABCMeta

        @abstractmethod
        def validate_existence(self, default_value_to_set):
            pass

        @abstractmethod
        def read_content(self, default_value_to_return):
            pass

        @abstractmethod
        def write_content(self, content_to_write, default_value_to_set):
            pass

#################
# FACTORY CLASS #
#################


class GetData(object):
    """
    Factory class that returns a specific DataStream object that can handle the platform's saving methods
     (Files/database)
    """
    @staticmethod
    def stream_object(file_name, db_key, siemplify, identifier):
        """
        Get a DataStream object based on platform attribute that dectate what system the platform should handle
        :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
        :param file_name: (str) the name of the file to be validated (in case the platform uses files)
        :param db_key: (str) the name of the key to be validated (in case the platform uses database)
        :param identifier: (str) The connector's identifier attribute.
        :return: A FileStream object if the platform should handle files,
                 or a DatabaseStream object if the platform should handle a database
        """

        if TIPCommon.platform_supports_db(siemplify):
            return DatabaseStream(db_key, siemplify, identifier)

        return FileStream(file_name, siemplify)

##################################################################
#           FILES CLASS         ##           FILES CLASS         #
##################################################################


class FileStream(AbstractDataStream):
    """
    A class representing a file object.
    This class extends the DataStream class.
    """

    def __init__(self, file_name, siemplify):
        """
        FileStream class constructor - create a FileStream object
        :param file_name: (str) The name of the file
        :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
        """

        self.siemplify = siemplify
        self.file_path = os.path.join(self.siemplify.run_folder, file_name)

    def validate_existence(self, default_value_to_set):
        """
        Validate the existence of a DataStream object.
        If it does not exist, initiate it with default value
        :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                     *Note that the default value passes through "json.dumps" before getting written
        """

        try:
            if not os.path.exists(self.file_path):
                with open(self.file_path, 'w+') as map_file:

                    map_file.write(json.dumps(default_value_to_set))
                    self.siemplify.LOGGER.info("File was created at {}".format(self.file_path))

        except Exception as e:
            self.siemplify.LOGGER.error("Unable to create file: {}".format(e))
            self.siemplify.LOGGER.exception(e)

    def read_content(self, default_value_to_return):
        """
        Read the content of a DataStream object.
        If the object contains no data, does not exist, return a default value
        :param default_value_to_return: (dict/list/str) the default value to be set in case a new file/key is created.
                                         If no value is supplied (therefore the default value 'None' is used),
                                         an internal default value of {} (dict) will be set as the new default value
        :return: (dict) The content inside the DataStream object,
                 the content passes through 'json.loads' before returning.
                 If the content could not be parsed as a json or if no content was found,
                 the default value will return as-is
                 (see "default_value_to_return" parameter doc for further explanation)
        """

        if not os.path.exists(self.file_path):

            self.siemplify.LOGGER.info('file: "{}" does not exist. Returning default value instead: {}'
                                       .format(self.file_path, default_value_to_return))
            return default_value_to_return

        try:
            with open(self.file_path, 'r') as f:
                return json.loads(f.read())

        except Exception as e:
            self.siemplify.LOGGER.error('Unable to read from file: {}'.format(e))
            self.siemplify.LOGGER.exception(e)
            return default_value_to_return

    def write_content(self, content_to_write, default_value_to_set):
        """
        Write content into a DataStream object.
        If the object contains no data, does not exist, return the default
        :param content_to_write: (dict/list/str) Content that would be written to the dedicated data stream.
                                 *Note that the content passes through "json.dumps" before getting written
        :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                     *Note that the default value passes through "json.dumps" before getting written.
                                     If no value is supplied (therefore the default value 'None' is used),
                                     an internal default value of {} (dict) will be set as the new default value
        """

        try:
            if not os.path.exists(os.path.dirname(self.file_path)):
                os.makedirs(os.path.dirname(self.file_path))

            with open(self.file_path, 'w') as f:

                try:

                    for chunk in json.JSONEncoder().iterencode(content_to_write):
                        f.write(chunk)

                except Exception as e:
                    self.siemplify.LOGGER.error("Failed writing to file: {}".format(e))
                    self.siemplify.LOGGER.exception(e)
                    # Move seeker to start of the file
                    f.seek(0)
                    # Empty the file's content (the partially written content that was written before the exception)
                    f.truncate()
                    # Write an empty dict to the file
                    f.write(json.dumps(default_value_to_set))

                return True

        except Exception as err:
            self.siemplify.LOGGER.error("Failed writing to file, ERROR: {}".format(err))
            self.siemplify.LOGGER.exception(err)
            return False


##################################################################
#         DATABASE CLASS        ##         DATABASE CLASS        #
##################################################################

class DatabaseStream(AbstractDataStream):
    """
    A class representing a database entry object.
    This class extends the DataStream class.
    """

    def __init__(self, db_key, siemplify, identifier):
        """
        DatabaseStream class constructor - create a DatabaseStream object
        :param db_key: (str) The name of the key under which it will be set in the database
        :param siemplify: (obj) An instance of the SDK SiemplifyConnectorExecution class
        """

        self.siemplify = siemplify
        self.db_key = db_key
        self.identifier = TIPCommon.none_to_default_value(
            value_to_check=identifier,
            value_to_return_if_none=self.siemplify.context.connector_info.identifier)

    def validate_existence(self, default_value_to_set):
        """
        Validate the existence of a DataStream object.
        If it does not exist, initiate it with default value
        :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                     *Note that the default value passes through "json.dumps" before getting written
        """
        try:
            existing_data = self.siemplify.get_connector_context_property(self.identifier, self.db_key)

            # Check if the db key exists
            # separators=(',', ':')
            if TIPCommon.is_empty_string_or_none(existing_data):
                str_data = json.dumps(default_value_to_set)
                self.siemplify.set_connector_context_property(self.identifier, self.db_key, str_data)
                self.siemplify.LOGGER.info("Created key: '{}' in the database".format(self.db_key))

        # If an error happened in the json.dumps methods
        except TypeError as err:
            self.siemplify.LOGGER.error('Failed to parse the default value as JSON. ERROR: {}'.format(err))
            self.siemplify.LOGGER.exception(err)
            raise

        # If there is a connection problem with the DB
        except Exception as e:
            self.siemplify.LOGGER.error("Exception was raised from the database. ERROR: {}".format(e))
            self.siemplify.LOGGER.exception(e)
            raise

    def read_content(self, default_value_to_return):
        """
        Read the content of a DataStream object.
        If the object contains no data, does not exist, return a default value
        :param default_value_to_return: (dict/list/str) the default value to be set in case a new file/key is created.
                                         If no value is supplied (therefore the default value 'None' is used),
                                         an internal default value of {} (dict) will be set as the new default value
        :return: (dict) The content inside the DataStream object,
                 the content passes through 'json.loads' before returning.
                 If the content could not be parsed as a json or if no content was found,
                 the default value will return as-is
                 (see "default_value_to_return" parameter doc for further explanation)
        """

        try:
            str_data = self.siemplify.get_connector_context_property(self.identifier, self.db_key)

            # Check if the db key exists
            if TIPCommon.is_empty_string_or_none(str_data):

                self.siemplify.LOGGER.info('Key: "{}" does not exist in the database. Returning default value instead:'
                                           ' {}'.format(self.db_key, default_value_to_return))
                return default_value_to_return

            data = json.loads(str_data)
            return data

        # If an error happened in the json.loads methods
        except TypeError as err:
            self.siemplify.LOGGER.error(
                'Failed to parse data as JSON. Returning default value instead: "{0}". \nERROR: {1}'.format(
                    default_value_to_return, err)
            )
            self.siemplify.LOGGER.exception(err)
            return default_value_to_return

        # If there is a connection problem with the DB
        except Exception as error:
            self.siemplify.LOGGER.error("Exception was raised from the database.  ERROR: {}.".format(error))
            self.siemplify.LOGGER.exception(error)
            raise

    def write_content(self, content_to_write, default_value_to_set):
        """
        Write content into a DataStream object.
        If the object contains no data, does not exist, return the default
        :param content_to_write: (dict/list/str) Content that would be written to the dedicated data stream.
                                   *Note that the content passes through "json.dumps" before getting written
        :param default_value_to_set: (dict/list/str) the default value to be set in case a new file/key is created.
                                        *Note that the default value passes through "json.dumps" before getting written.
                                         If no value is supplied (therefore the default value 'None' is used),
                                         an internal default value of {} (dict) will be set as the new default value
        """
        # separators=(',', ':')
        try:
            str_data = json.dumps(content_to_write)
            self.siemplify.set_connector_context_property(self.identifier, self.db_key, str_data)

        # If an error happened in the json.dumps methods
        except TypeError as err:
            self.siemplify.LOGGER.error(
                'Failed parsing JSON to string. Writing default value instead: "{}". \nERROR: {}'.format(
                    default_value_to_set, err)
            )
            self.siemplify.LOGGER.exception(err)
            self.siemplify.set_connector_context_property(
                self.identifier, self.db_key, json.dumps(default_value_to_set)
            )
        # If there is a connection problem with the DB
        except Exception as err:
            self.siemplify.LOGGER.error("Exception was raised from the database.  ERROR: {}".format(err))
            self.siemplify.LOGGER.exception(err)
            raise

